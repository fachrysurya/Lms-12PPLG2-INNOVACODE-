# Edu Class — Admin (Next.js + MongoDB)

Project ini dibangun berdasarkan desain Figma untuk role **Admin**.
Sudah selesai: **Login** (dengan autentikasi beneran ke MongoDB).
Menyusul: Dashboard, Jurusan, Kelas, Mata Pelajaran, Manajemen Guru,
Manajemen Siswa, Manajemen Kepala Sekolah, Manajemen Kurikulum,
Registrasi, Download Data, Profile.

## Cara menjalankan di komputer kamu

1. Install dependency:
   ```bash
   npm install
   ```

2. Pastikan MongoDB kamu sudah jalan (lokal atau MongoDB Atlas).

3. Salin file environment:
   ```bash
   cp .env.local.example .env.local
   ```
   Lalu isi `MONGODB_URI` dan `JWT_SECRET` di `.env.local`.

4. Buat akun admin pertama (karena password disimpan ter-hash, tidak bisa
   insert manual ke database):
   ```bash
   npm run seed:admin
   ```
   Ini akan membuat akun: `username: admin`, `password: admin123`
   (bisa diganti langsung di `scripts/seedAdmin.js` sebelum dijalankan).

5. Jalankan server development:
   ```bash
   npm run dev
   ```
   Buka [http://localhost:3000](http://localhost:3000) — otomatis
   diarahkan ke halaman Login.

## Catatan tentang gambar/ilustrasi

Beberapa elemen visual di halaman Login (ilustrasi HP, logo "Edu Class",
awan dekoratif) belum berupa gambar asli — saya ganti sementara dengan
kotak placeholder abu-abu putus-putus, karena saya tidak punya akses
untuk mengunduh aset gambar dari Figma. Untuk hasil 100% sama persis:

1. Buka file Figma-nya, pilih layer gambar yang dimaksud.
2. Klik kanan → Export → simpan sebagai PNG/SVG ke folder `public/images/`.
3. Ganti div placeholder di `app/login/page.js` dengan tag `<img src="/images/nama-file.png" />`.

## Struktur project

```
app/
  login/page.js            -> Halaman Login (sesuai Figma)
  admin/dashboard/page.js  -> Dashboard admin (placeholder, menyusul)
  api/auth/login/route.js  -> API endpoint login (cek ke MongoDB)
lib/mongodb.js             -> Koneksi MongoDB
models/Admin.js            -> Schema akun admin
middleware.js               -> Proteksi halaman /admin (wajib login)
scripts/seedAdmin.js       -> Script buat akun admin pertama
```
