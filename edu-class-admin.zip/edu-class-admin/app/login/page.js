"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { User, Lock } from "lucide-react";

const ROLES = ["Admin", "Guru", "Siswa", "Kurikulum", "Kepsek"];

export default function LoginPage() {
  const router = useRouter();
  const [role, setRole] = useState("Admin");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleLogin(e) {
    e.preventDefault();
    setError("");

    if (role !== "Admin") {
      setError(`Login untuk role ${role} belum tersedia — menyusul.`);
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.message || "Login gagal.");
        return;
      }

      router.push("/admin/dashboard");
    } catch (err) {
      setError("Tidak bisa terhubung ke server.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="bg-white relative w-[1440px] h-[1024px] mx-auto overflow-hidden">
      {/* Panel kiri: ilustrasi + tagline */}
      <div className="absolute left-[-115px] top-[-181px] w-[838px] h-[1237px]">
        <div className="absolute bg-edu-bg h-[1056px] left-[115px] top-[181px] w-[838px]" />

        {/* Dekorasi lingkaran (pengganti ilustrasi awan dari Figma) */}
        <div className="absolute h-[279px] left-0 top-[139px] w-[275px] rounded-full bg-edu-blue" />
        <div className="absolute h-[279px] left-[138px] top-0 w-[275px] rounded-full bg-edu-cyan opacity-90" />

        {/* Placeholder ilustrasi HP + buku — ganti dengan export asli dari Figma di public/images/phone-illustration.png */}
        <div className="absolute h-[526px] left-[212px] top-[659px] w-[321px] rounded-2xl bg-edu-bg border-2 border-dashed border-gray-300 flex items-center justify-center text-gray-400 text-sm text-center px-4">
          Ganti dengan ilustrasi HP
          <br />
          (public/images/phone-illustration.png)
        </div>
        <div className="absolute h-[346px] left-[212px] top-[797px] w-[576px] rounded-2xl" />

        <p className="absolute -translate-x-1/2 left-[501.5px] top-[573px] w-[451px] font-inria-serif text-[16px] text-center leading-normal">
          <span className="font-bold text-black">‘’</span>
          <span className="font-bold text-edu-blue">
            A smart digital classroom platform designed to streamline
            assignments, learning materials, and communication while
            enhancing the overall learning experience
          </span>
          <span className="font-bold text-black">’’</span>
        </p>

        <h1 className="absolute -translate-x-1/2 left-[500px] top-[466px] font-inria-serif font-bold text-[48px] text-black whitespace-pre">
          Edu Class
        </h1>

        {/* Placeholder logo — ganti dengan public/images/logo.png */}
        <div className="absolute h-[335px] left-[285px] top-[221px] w-[430px] rounded-2xl bg-white border-2 border-dashed border-gray-300 flex items-center justify-center text-gray-400 text-sm">
          Ganti dengan logo Edu Class
        </div>
      </div>

      {/* Tombol back (pojok kiri bawah) */}
      <div className="absolute flex h-[40px] items-center justify-center left-[19px] top-[963px] w-[90px]">
        <button
          type="button"
          onClick={() => router.push("/")}
          className="w-full h-full rounded-[15px] bg-edu-cyan text-white text-sm rotate-180"
          aria-label="Kembali"
        >
          <span className="inline-block rotate-180">←</span>
        </button>
      </div>

      {/* Card form login */}
      <div className="absolute bg-edu-blue h-[480px] left-[838px] rounded-[20px] top-[409px] w-[498px]">
        <form onSubmit={handleLogin}>
          {/* Username */}
          <label className="absolute left-[30px] top-[18px] font-semibold text-[20px] text-black">
            Username
          </label>
          <div className="absolute bg-white h-[53px] left-[30px] rounded-[15px] top-[54px] w-[445px]">
            <User className="absolute left-[10px] top-[13px] w-[27px] h-[27px] text-gray-400" />
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Masukkan Username"
              required
              className="absolute left-[45px] top-[16px] w-[380px] text-[16px] text-black placeholder-[#d9d9d9] outline-none bg-transparent"
            />
          </div>
          <p className="absolute left-[30px] top-[118px] text-[14px] text-[#d9d9d9] font-medium">
            Gunakan 10 digit angka sesuai NIS sekolah
          </p>

          {/* Password */}
          <label className="absolute left-[30px] top-[151px] font-semibold text-[20px] text-black">
            Password
          </label>
          <div className="absolute bg-white h-[53px] left-[30px] rounded-[15px] top-[186px] w-[445px]">
            <Lock className="absolute left-[10px] top-[14px] w-[24px] h-[24px] text-gray-400" />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Masukkan Password"
              required
              className="absolute left-[45px] top-[16px] w-[380px] text-[16px] text-black placeholder-[#d9d9d9] outline-none bg-transparent"
            />
          </div>
          <p className="absolute left-[30px] top-[253px] text-[14px] text-[#d9d9d9] font-medium">
            Masukkan password dari akun anda.
          </p>

          {/* Role tabs */}
          <div className="absolute left-[42px] top-[294px] flex gap-[10.8px]">
            {ROLES.map((r) => (
              <button
                type="button"
                key={r}
                onClick={() => setRole(r)}
                className={`h-[37px] w-[70.342px] rounded-[15px] text-[13px] font-bold ${
                  role === r ? "bg-edu-cyan text-white" : "bg-white text-black"
                }`}
              >
                {r}
              </button>
            ))}
          </div>

          {error && (
            <p className="absolute left-[42px] top-[340px] w-[420px] text-[12px] text-red-100 bg-red-500/80 rounded-md px-2 py-1">
              {error}
            </p>
          )}

          {/* Tombol Login */}
          <button
            type="submit"
            disabled={loading}
            className="absolute bg-edu-cyan h-[53px] left-[172px] rounded-[15px] top-[380px] w-[154px] text-white font-semibold text-[20px] disabled:opacity-60"
          >
            {loading ? "..." : "Login"}
          </button>
        </form>
      </div>
    </div>
  );
}
