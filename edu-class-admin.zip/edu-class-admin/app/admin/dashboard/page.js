export default function AdminDashboardPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-edu-bg">
      <div className="text-center">
        <h1 className="text-2xl font-bold text-edu-blue">
          Login berhasil ✅
        </h1>
        <p className="text-gray-500 mt-2">
          Halaman Dashboard admin (sesuai Figma) akan dibangun di langkah
          berikutnya.
        </p>
      </div>
    </div>
  );
}
