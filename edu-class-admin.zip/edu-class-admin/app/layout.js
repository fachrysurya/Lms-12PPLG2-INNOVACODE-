import { Inter, Inria_Serif } from "next/font/google";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  weight: ["400", "500", "600", "700"],
});

const inriaSerif = Inria_Serif({
  subsets: ["latin"],
  variable: "--font-inria-serif",
  weight: ["400", "700"],
});

export const metadata = {
  title: "Edu Class",
  description: "A smart digital classroom platform",
};

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <body className={`${inter.variable} ${inriaSerif.variable} font-inter`}>
        {children}
      </body>
    </html>
  );
}
