/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        "edu-blue": "#0f7ec3",
        "edu-cyan": "#08addb",
        "edu-bg": "#fafafa",
      },
      fontFamily: {
        inter: ["var(--font-inter)", "sans-serif"],
        "inria-serif": ["var(--font-inria-serif)", "serif"],
      },
    },
  },
  plugins: [],
};
