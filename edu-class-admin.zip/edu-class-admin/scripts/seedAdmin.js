// Jalankan: npm run seed:admin
// Membuat 1 akun admin awal supaya bisa login (username: admin, password: admin123)
require("dotenv").config({ path: ".env.local" });
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

async function main() {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    console.error("MONGODB_URI belum diisi di .env.local");
    process.exit(1);
  }

  await mongoose.connect(uri);

  const AdminSchema = new mongoose.Schema({
    name: String,
    username: { type: String, unique: true },
    password: String,
  });
  const Admin = mongoose.models.Admin || mongoose.model("Admin", AdminSchema);

  const username = "admin";
  const plainPassword = "admin123";

  const existing = await Admin.findOne({ username });
  if (existing) {
    console.log("Akun admin dengan username 'admin' sudah ada. Tidak dibuat ulang.");
    process.exit(0);
  }

  const hashed = await bcrypt.hash(plainPassword, 10);
  await Admin.create({ name: "Administrator", username, password: hashed });

  console.log("Akun admin berhasil dibuat!");
  console.log("Username:", username);
  console.log("Password:", plainPassword);
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
