import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Edu Class",
  description: "Smart Education Class System",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}