export default function Home() {
  return (
    <main>
      {/* HEADER */}
      <header className="header">
        <div className="header-container">

          <div className="logo">
            <div className="logo-icon">
              <div className="logo-top"></div>
              <div className="logo-bottom"></div>
            </div>

            <span>Edu Class</span>
          </div>

          <nav className="navigation">
            <a href="#home" className="active">
              Home
            </a>

            <a href="#about">
              Tentang
            </a>

            <a href="#contact">
              Kontak
            </a>

            <a href="#" className="login-button">
              Login
            </a>
          </nav>

        </div>
      </header>


      {/* HERO */}
      <section className="hero" id="home">
        <div className="hero-container">

          <div className="hero-content">

            <span className="badge">
              E-Learning Multi Class System
            </span>

            <h1>
              Smart Education
              <span>Class System</span>
            </h1>

            <p>
              Edu Class adalah platform manajemen pendidikan sekolah
              digital yang membantu sekolah dalam proses belajar
              mengajar menjadi lebih efektif dan efisien.
            </p>

            <a href="#" className="hero-login">
              Login
            </a>

          </div>


          <div className="hero-laptop">

            <div className="laptop">

              <div className="laptop-screen">

                <div className="screen-inner">

                  <div className="screen-logo">
                    <div className="screen-logo-top"></div>
                    <div className="screen-logo-bottom"></div>
                  </div>

                  <span>edu class</span>

                </div>

              </div>

              <div className="laptop-base"></div>

            </div>

          </div>

        </div>
      </section>


      {/* ABOUT */}
      <section className="about" id="about">

        <div className="section-container">

          <h2>
            about Edu Class
          </h2>


          <div className="about-content">

            <div className="about-text">

              <h3>
                Tentang Edu Class
              </h3>

              <p>
                Edu Class adalah platform manajemen pendidikan sekolah
                digital yang membantu dalam mengelola data siswa, guru,
                materi, dan assessment.
              </p>

            </div>


            <div className="about-cards">

              <div className="about-card">

                <div className="about-icon">
                  ◉
                </div>

                <h4>
                  VISI
                </h4>

                <p>
                  Menjadi sistem manajemen pendidikan digital yang
                  modern, efektif dan mudah digunakan untuk semua
                  kalangan sekolah.
                </p>

              </div>


              <div className="about-card">

                <div className="about-icon">
                  ◎
                </div>

                <h4>
                  MISI
                </h4>

                <p>
                  1. Menyediakan sistem belajar yang mudah digunakan.
                  <br />
                  2. Meningkatkan proses belajar mengajar.
                  <br />
                  3. Menyediakan laporan yang cukup lengkap.
                </p>

              </div>

            </div>

          </div>

        </div>

      </section>


      {/* FITUR */}
      <section className="features">

        <div className="section-container">

          <h2>
            Apa yang bisa dilakukan di dalam Edu Class
          </h2>

          <p className="features-subtitle">
            Fitur untuk setiap bagian belajar mengajar dari siswa.
          </p>


          <div className="feature-grid">

            <div className="feature-card">

              <div className="feature-icon">
                ▣
              </div>

              <h3>
                Upload Materi
              </h3>

              <p>
                Guru dapat mengupload materi dalam bentuk PDF maupun
                link pembelajaran.
              </p>

            </div>


            <div className="feature-card">

              <div className="feature-icon">
                ✓
              </div>

              <h3>
                Asesmen Online
              </h3>

              <p>
                Siswa dapat mengikuti berbagai asesmen secara online
                melalui sistem.
              </p>

            </div>


            <div className="feature-card">

              <div className="feature-icon">
                ▣
              </div>

              <h3>
                Tugas &amp; Proyek
              </h3>

              <p>
                Guru dapat memberikan tugas dan proyek pembelajaran
                kepada siswa.
              </p>

            </div>


            <div className="feature-card">

              <div className="feature-icon">
                ↓
              </div>

              <h3>
                Rekap Nilai
              </h3>

              <p>
                Melihat hasil nilai siswa secara mudah dan terorganisir.
              </p>

            </div>

          </div>

        </div>

      </section>


      {/* FOOTER */}
      <footer className="footer" id="contact">

        <div className="footer-container">

          <div className="footer-brand">

            <div className="footer-logo">

              <div className="logo-icon">
                <div className="logo-top"></div>
                <div className="logo-bottom"></div>
              </div>

              <span>
                Edu Class
              </span>

            </div>

            <p>
              Edu Class adalah sistem informasi pendidikan yang membantu
              sekolah dalam mengelola proses pembelajaran.
            </p>

          </div>


          <div className="footer-navigation">

            <h3>
              Navigasi
            </h3>

            <a href="#home">
              Home
            </a>

            <a href="#about">
              Tentang
            </a>

            <a href="#contact">
              Kontak
            </a>

            <a href="#">
              Login
            </a>

          </div>


          <div className="footer-contact">

            <h3>
              Kontak
            </h3>

            <p>
              Jl. Pendidikan No. 10, Indonesia
            </p>

            <p>
              info@educlass.com
            </p>

            <p>
              021 7789 9000
            </p>

          </div>

        </div>

      </footer>

    </main>
  );
}